package studio.fir.doodleinvaders

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.util.Base64
import android.view.View
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.content.FileProvider
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.WebViewAssetLoader
import java.io.File

/**
 * رابط اللعبة على الإنترنت (اختياري).
 * عند مشاركة وحش أو نتيجة تُرسل الروابط بهذا العنوان بدل عنوان التطبيق الداخلي.
 * مثال: "https://your-site.web.app/"  — اتركه فارغاً إن لم يكن للعبة موقع.
 */
private const val SHARE_BASE_URL = ""

private const val HOST = "appassets.androidplatform.net"
private const val GAME_URL = "https://$HOST/assets/index.html"

class MainActivity : Activity() {

    private lateinit var web: WebView

    @SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

        val assetLoader = WebViewAssetLoader.Builder()
            .setDomain(HOST)
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web = WebView(this).apply {
            setBackgroundColor(Color.parseColor("#D9CFB8"))
            overScrollMode = View.OVER_SCROLL_NEVER
            isVerticalScrollBarEnabled = false
            isHorizontalScrollBarEnabled = false
            isLongClickable = false
            setOnLongClickListener { true }          // لا قائمة تحديد أثناء الرسم
            isHapticFeedbackEnabled = false

            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true             // حفظ التقدم (localStorage)
                mediaPlaybackRequiresUserGesture = false
                allowFileAccess = false
                allowContentAccess = false
                setSupportZoom(false)
                builtInZoomControls = false
                displayZoomControls = false
                cacheMode = WebSettings.LOAD_DEFAULT
                textZoom = 100
            }

            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(
                    view: WebView, request: WebResourceRequest
                ): WebResourceResponse? = assetLoader.shouldInterceptRequest(request.url)

                override fun shouldOverrideUrlLoading(
                    view: WebView, request: WebResourceRequest
                ): Boolean {
                    if (request.url.host == HOST) return false
                    try {
                        startActivity(Intent(Intent.ACTION_VIEW, request.url))
                    } catch (_: ActivityNotFoundException) {
                    }
                    return true
                }

                override fun onPageFinished(view: WebView, url: String?) {
                    view.evaluateJavascript(SHIM_JS, null)
                }

                override fun onRenderProcessGone(
                    view: WebView, detail: RenderProcessGoneDetail
                ): Boolean {
                    recreate()
                    return true
                }
            }
            addJavascriptInterface(Bridge(), "AndroidBridge")
        }
        setContentView(web)

        // لوحة المفاتيح (مربع كتابة وصف الوحش) لا تغطي الصفحة
        ViewCompat.setOnApplyWindowInsetsListener(web) { v, insets ->
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime()).bottom
            v.setPadding(0, 0, 0, ime)
            insets
        }

        hideSystemBars()

        if (savedInstanceState == null) web.loadUrl(GAME_URL) else web.restoreState(savedInstanceState)
    }

    private fun hideSystemBars() {
        WindowInsetsControllerCompat(window, window.decorView).apply {
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            hide(WindowInsetsCompat.Type.systemBars())
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
        web.resumeTimers()
    }

    override fun onPause() {
        web.onPause()
        web.pauseTimers()
        super.onPause()
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }

    /** جسر المشاركة: WebView لا يدعم navigator.share، فنوصله بنافذة المشاركة الأصلية. */
    private inner class Bridge {
        @JavascriptInterface
        fun shareBase(): String = SHARE_BASE_URL

        @JavascriptInterface
        fun shareText(text: String) {
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, text)
            }
            runOnUiThread { startActivity(Intent.createChooser(send, null)) }
        }

        @JavascriptInterface
        fun shareImage(base64: String, text: String) {
            try {
                val dir = File(cacheDir, "shared").apply { mkdirs() }
                val file = File(dir, "doodle-invaders.png")
                file.writeBytes(Base64.decode(base64, Base64.DEFAULT))
                val uri = FileProvider.getUriForFile(
                    this@MainActivity, "$packageName.fileprovider", file
                )
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "image/png"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    if (text.isNotBlank()) putExtra(Intent.EXTRA_TEXT, text)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                runOnUiThread { startActivity(Intent.createChooser(send, null)) }
            } catch (_: Exception) {
            }
        }
    }

    private companion object {
        /** يعوّض navigator.share / canShare بما يستدعي الجسر الأصلي. */
        const val SHIM_JS = """
(function(){
  if (window.__dShim || !window.AndroidBridge) return;
  window.__dShim = 1;
  var B = window.AndroidBridge, BASE = B.shareBase();
  function fix(t){
    if (BASE) t = t.split(location.origin + location.pathname).join(BASE);
    return t;
  }
  navigator.canShare = function(d){
    return !!(d && ((d.files && d.files.length) || d.text || d.url || d.title));
  };
  navigator.share = function(d){
    d = d || {};
    var txt = fix([d.text, d.url].filter(Boolean).join(' '));
    if (d.files && d.files.length) {
      return new Promise(function(res, rej){
        var r = new FileReader();
        r.onload = function(){ B.shareImage(String(r.result).split(',')[1] || '', txt); res(); };
        r.onerror = function(){ rej(r.error); };
        r.readAsDataURL(d.files[0]);
      });
    }
    B.shareText(txt);
    return Promise.resolve();
  };
})();
"""
    }
}
