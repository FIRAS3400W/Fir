# دودل الغزاة — مشروع أندرويد

اللعبة نفسها (ملف HTML الأصلي بكل ما فيه) تعمل داخل تطبيق أندرويد أصلي بـ Kotlin، أوفلاين، بملء الشاشة وبوضع عمودي.

## بناء الـ APK
1. ثبّت Android Studio (الإصدار الحديث).
2. File ← Open ← اختر مجلد `DoodleInvaders` وانتظر انتهاء Sync (يحتاج إنترنت أول مرة).
3. Build ← Build Bundle(s) / APK(s) ← **Build APK(s)**.
4. الملف في: `app/build/outputs/apk/debug/app-debug.apk` — انقله للهاتف وثبّته.

أو من الطرفية: `gradle assembleDebug` (أو `./gradlew assembleDebug` بعد أن يولّد Android Studio ملف الـ wrapper).

## للنشر على Google Play
Build ← Generate Signed Bundle / APK ← Android App Bundle، وأنشئ مفتاح توقيع واحفظه جيداً.

## تحديث اللعبة لاحقاً
استبدل `app/src/main/assets/index.html` بالنسخة الجديدة وابنِ من جديد.

## إعدادات
- `MainActivity.kt` ← `SHARE_BASE_URL`: ضع رابط اللعبة على الإنترنت ليظهر في روابط مشاركة الوحوش. اتركه فارغاً إن لم يوجد.
- `app/build.gradle.kts` ← `versionCode` / `versionName` عند كل إصدار.

## ما أضافه التطبيق فوق اللعبة
- ملء الشاشة وإبقاء الشاشة مضاءة، وتجاوز الحواف/النوتش.
- مشاركة أصلية (النص والصورة) بدل navigator.share غير المدعوم في WebView.
- الصوت والموسيقى يعملان دون ضغطة إضافية.
- حفظ التقدم (localStorage) بين مرات التشغيل.
- لوحة المفاتيح لا تغطي مربع كتابة وصف الوحش.
- إيقاف اللعبة تلقائياً عند الخروج من التطبيق.

## ملاحظات
- الخطوط (Permanent Marker / Lalezar) تُحمّل من Google Fonts عند وجود إنترنت؛ بدونه تُستخدم خطوط الهاتف البديلة. لتكون الخطوط أوفلاين ضع ملفات الخط في assets.
- صوت `speechSynthesis` (النطق الآلي) غير موجود في WebView، فيُتجاهل بصمت.
- دالة الذكاء الاصطناعي ما زالت `YOURPROJECT` في الملف الأصلي، فتعمل المولّدات المحلية حتى تضع رابط دالتك.
